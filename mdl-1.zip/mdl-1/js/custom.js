
$( document ).ready(function(){ 


$(".button-collapse").sideNav();

 $('.carousel').carousel();

      $('.slider').slider();
   





    });




function initMap() {
        var uluru = {lat: 27.66294768, lng: 85.30596659};
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 15,
          center: uluru
        });
        var marker = new google.maps.Marker({
          position: uluru,
          map: map
        });
      }


